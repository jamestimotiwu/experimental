#### 0.53.1 (2019-07-05)

### 0.53.0 (2019-04-08)

##### Other Changes

*  fixing a bug where a texutre isn't cleared when expected to due to start() and startAt() setting STATE to be STATE.sequenced before a clearTexture is called. ([cbd44a11](https://github.com/bbc/VideoContext/commit/cbd44a119749bca69c8b7c1b0de3cb9e4cbad36c))

#### 0.52.13 (2019-01-14)

#### 0.52.12 (2018-12-18)

#### 0.52.11 (2018-12-13)

#### 0.52.10 (2018-11-06)

#### 0.52.9 (2018-11-05)

#### 0.52.8 (2018-09-28)

#### 0.52.7 (2018-08-07)

#### 0.52.6 (2018-07-26)

#### 0.52.5 (2018-07-24)

#### 0.52.3 (2018-07-20)

#### 0.52.2 (2018-07-09)

